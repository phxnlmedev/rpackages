
#'
#' @export
InvLogit=1
#'
#' @export
InvProbit=2
#'
#' @export
InvLogLog=3
#'
#' @export
InvClogClog=4
#'
#' @export
InvCustom=5

