library(testthat)
library(RsNlme)

test_package("RsNlme")
