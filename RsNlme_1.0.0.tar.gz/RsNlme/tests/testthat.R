library(testthat)
library(RsNlme)

test_check("RsNlme")
