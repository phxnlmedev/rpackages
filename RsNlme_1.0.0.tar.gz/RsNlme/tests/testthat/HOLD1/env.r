    Sys.setenv("NLME_ROOT_DIRECTORY"=
			  "D:/SDCard/NlmeInstall_04_30_18/")
    Sys.setenv("INSTALLDIR"=
              "D:/SDCard/NlmeInstall_04_30_18//InstallDirNLME")
    Sys.setenv("NLME_HASH"="1430741471")
