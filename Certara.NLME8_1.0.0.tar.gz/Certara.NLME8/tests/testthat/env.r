    Sys.setenv("NLME_ROOT_DIRECTORY"=
			  "C:/jenkins/workspace/Phoenix_PML_Build_Windows/WindowsPackage")
    Sys.setenv("INSTALLDIR"=
              "C:/jenkins/workspace/Phoenix_PML_Build_Windows/WindowsPackage/InstallDirNLME")
    Sys.setenv("NLME_HASH"="1430741471")
