
This directory contains all executables/libraries/scripts necessary to run
NLME7 from commandline.

