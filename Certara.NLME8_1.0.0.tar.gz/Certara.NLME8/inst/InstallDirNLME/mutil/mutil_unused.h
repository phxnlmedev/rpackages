#pragma once

double probit(double p);
