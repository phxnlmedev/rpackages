#pragma once

typedef int BOOL;
#define FALSE 0
#define TRUE 1
