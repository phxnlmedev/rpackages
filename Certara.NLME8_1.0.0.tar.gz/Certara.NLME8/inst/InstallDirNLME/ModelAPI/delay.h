#pragma once

// delay modes for bolus doses
#define DBM_ADD_INCREMENTS 1
#define DBM_SHORT_INFUSION 2
#define DBM_DOSE_TABLE  3

