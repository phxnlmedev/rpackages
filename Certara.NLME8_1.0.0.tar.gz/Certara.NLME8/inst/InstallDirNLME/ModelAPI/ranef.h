#pragma once

void GetRanef1Name(int * _pi, char * _nm);
void GetRanef2Name(int * _pi, char * _nm);
void GetRanef3Name(int * _pi, char * _nm);
void GetRanef4Name(int * _pi, char * _nm);
void GetRanef5Name(int * _pi, char * _nm);

