#pragma once

void GetNumCVMean(int * _pn);
void GetCVMeanName(int * _pi, char * _nm);
void GetCVMean(int * _pi, double * _pv);
void SetCVMean(int * _pi, double * _pv);
void GetNumCVMedian(int * _pn);
void GetCVMedianName(int * _pi, char * _nm);
void GetCVMedian(int * _pi, double * _pv);
void SetCVMedian(int * _pi, double * _pv);
